from flask import Flask, request, jsonify
import uuid
from collections import deque
import re
import openai

openai.api_key = "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"  # Replace with your actual OpenAI key

app = Flask(__name__)

sessions = {}
global_counter = {}

class GameSession:
    def __init__(self, seed):
        self.words = deque([seed])
        self.score = 0

    def add_word(self, word):
        self.words.append(word)
        self.score += 1

    def exists(self, word):
        return word in self.words

    def history(self):
        return list(self.words)

def is_clean(text):
    return not re.search(r"(damn|hell|shit|fuck|badword)", text, re.IGNORECASE)

@app.route("/", methods=["GET"])
def home():
    return "Welcome! Use POST /v1/guess with {'session_id': ..., 'word': ...}"

@app.route("/v1/guess", methods=["POST"])
def guess():
    data = request.get_json()
    session_id = data.get("session_id") or str(uuid.uuid4())
    word = data.get("word", "").strip().lower()

    if not is_clean(word):
        return jsonify({"error": "Inappropriate word"}), 400

    if session_id not in sessions:
        sessions[session_id] = GameSession("rock")

    session = sessions[session_id]

    if session.exists(word):
        return jsonify({"game_over": True, "message": "Duplicate guess!"})

    current = session.words[-1]
    prompt = f"Does '{word}' beat '{current}' in a creative sense?"

    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=10
    )
    verdict = response.choices[0].message.content.strip()

    if "yes" in verdict.lower():
        session.add_word(word)
        global_counter[word] = global_counter.get(word, 0) + 1
        return jsonify({
            "game_over": False,
            "message": f"✅ '{word}' beats '{current}'. Count: {global_counter[word]}",
            "score": session.score,
            "session_id": session_id
        })
    else:
        return jsonify({"game_over": True, "message": f"'{word}' does not beat '{current}'."})

